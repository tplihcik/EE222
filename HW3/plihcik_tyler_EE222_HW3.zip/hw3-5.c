

#include <stdio.h>

int main() ;

int main(  )
{
   float numOne ;
   float numTwo ;

   float difference = 0 ;
   float product = 0 ;

   float result = 0 ;

   printf( "Enter a floating-point number: " ) ;
   scanf( "%f" , &numOne ) ;

   printf( "Enter a floating-point number: " ) ;
   scanf( "%f" , &numOne ) ;

   difference = numOne - numTwo ;
   product = numOne * numTwo ;

   result = difference / product ;

   printf( "%f" , result ) ;


}
